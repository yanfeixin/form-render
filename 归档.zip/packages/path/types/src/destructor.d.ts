import { DestructorRules, Node, Segments } from './types';
interface Mutators {
    getIn: (segments: Segments, source: any) => any;
    setIn: (segments: Segments, source: any, value: any) => void;
    deleteIn?: (segments: Segments, source: any) => any;
    existIn?: (segments: Segments, source: any, start: number) => boolean;
}
export declare function getDestructor(source: string): any;
export declare function setDestructor(source: string, rules: DestructorRules): void;
export declare function parseDestructorRules(node: Node): DestructorRules;
export declare function setInByDestructor(source: any, rules: DestructorRules, value: any, mutators: Mutators): void;
export declare function getInByDestructor(source: any, rules: DestructorRules, mutators: Mutators): {};
export declare function deleteInByDestructor(source: any, rules: DestructorRules, mutators: Mutators): void;
export declare function existInByDestructor(source: any, rules: DestructorRules, start: number, mutators: Mutators): boolean;
export {};
