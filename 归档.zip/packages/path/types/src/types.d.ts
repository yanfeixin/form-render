import { Path } from './index';
interface INode {
    type?: string;
    after?: Node;
    depth?: number;
}
export type Node = IdentifierNode | WildcardOperatorNode | GroupExpressionNode | RangeExpressionNode | DestructorExpressionNode | ObjectPatternNode | ArrayPatternNode | DotOperatorNode | ExpandOperatorNode | INode;
export type IdentifierNode = {
    type: 'Identifier';
    value: string;
    arrayIndex?: boolean;
} & INode;
export type IgnoreExpressionNode = {
    type: 'IgnoreExpression';
    value: string;
} & INode;
export type DotOperatorNode = {
    type: 'DotOperator';
} & INode;
export type WildcardOperatorNode = {
    type: 'WildcardOperator';
    filter?: GroupExpressionNode | RangeExpressionNode;
    optional?: boolean;
} & INode;
export type ExpandOperatorNode = {
    type: 'ExpandOperator';
} & INode;
export type GroupExpressionNode = {
    type: 'GroupExpression';
    value: Node[];
    isExclude?: boolean;
} & INode;
export type RangeExpressionNode = {
    type: 'RangeExpression';
    start?: IdentifierNode;
    end?: IdentifierNode;
} & INode;
export type DestructorExpressionNode = {
    type: 'DestructorExpression';
    value?: ObjectPatternNode | ArrayPatternNode;
    source?: string;
} & INode;
export type ObjectPatternNode = {
    type: 'ObjectPattern';
    properties: ObjectPatternPropertyNode[];
} & INode;
export type ObjectPatternPropertyNode = {
    type: 'ObjectPatternProperty';
    key: IdentifierNode;
    value?: ObjectPatternNode[] | ArrayPatternNode[] | IdentifierNode;
} & INode;
export type ArrayPatternNode = {
    type: 'ArrayPattern';
    elements: ObjectPatternNode[] | ArrayPatternNode[] | IdentifierNode[];
} & INode;
export interface DestructorRule {
    key?: string | number;
    path?: Array<number | string>;
}
export type MatcherFunction = ((path: Segments) => boolean) & {
    path: Path;
};
export type Pattern = string | number | Path | Segments | MatcherFunction | RegExp;
export type DestructorRules = DestructorRule[];
export type Segments = Array<string | number>;
export declare function isType<T>(type: string): (obj: any) => obj is T;
export declare const isIdentifier: (obj: any) => obj is IdentifierNode;
export declare const isIgnoreExpression: (obj: any) => obj is IgnoreExpressionNode;
export declare const isDotOperator: (obj: any) => obj is DotOperatorNode;
export declare const isWildcardOperator: (obj: any) => obj is WildcardOperatorNode;
export declare const isExpandOperator: (obj: any) => obj is ExpandOperatorNode;
export declare const isGroupExpression: (obj: any) => obj is GroupExpressionNode;
export declare const isRangeExpression: (obj: any) => obj is RangeExpressionNode;
export declare const isDestructorExpression: (obj: any) => obj is DestructorExpressionNode;
export declare const isObjectPattern: (obj: any) => obj is ObjectPatternNode;
export declare const isObjectPatternProperty: (obj: any) => obj is ObjectPatternPropertyNode;
export declare const isArrayPattern: (obj: any) => obj is ArrayPatternNode;
export type KeyType = string | number | symbol;
export interface IAccessors {
    get?: (source: any, key: KeyType) => any;
    set?: (source: any, key: KeyType, value: any) => any;
    has?: (source: any, key: KeyType) => boolean;
    delete?: (source: any, key: KeyType) => any;
}
export interface IRegistry {
    accessors?: IAccessors;
}
export {};
