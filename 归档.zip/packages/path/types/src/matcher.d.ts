import { DestructorExpressionNode, ExpandOperatorNode, GroupExpressionNode, IdentifierNode, IgnoreExpressionNode, Node, RangeExpressionNode, Segments, WildcardOperatorNode } from './types';
export interface IRecord {
    score: number;
}
export declare class Matcher {
    private tree;
    private stack;
    private record;
    private excluding;
    private wildcards;
    private path;
    constructor(tree: Node, record?: any);
    next(node: Node, pos: number): any;
    shot(): void;
    take(pos: number): string;
    matchExcludeIdentifier(matched: boolean, node: Node, pos: number): any;
    matchIdentifier(node: IdentifierNode, pos: number): any;
    matchIgnoreExpression(node: IgnoreExpressionNode, pos: number): any;
    matchDestructorExpression(node: DestructorExpressionNode, pos: number): any;
    matchExpandOperator(node: ExpandOperatorNode, pos: number): any;
    matchWildcardOperator(node: WildcardOperatorNode, pos: number): any;
    matchGroupExpression(node: GroupExpressionNode, pos: number): any;
    matchRangeExpression(node: RangeExpressionNode, pos: number): any;
    matchNode(node: Node, pos?: number): any;
    match(path: Segments): {
        matched: any;
        record: IRecord;
    };
    static matchSegments(source: Segments, target: Segments, record?: any): {
        matched: any;
        record: any;
    };
}
