import { Tokenizer } from './tokenizer';
import { Token } from './tokens';
import { ArrayPatternNode, DestructorExpressionNode, ExpandOperatorNode, GroupExpressionNode, IdentifierNode, IgnoreExpressionNode, Node, ObjectPatternNode, ObjectPatternPropertyNode, RangeExpressionNode, Segments, WildcardOperatorNode } from './types';
import { Path } from './index';
export declare class Parser extends Tokenizer {
    isMatchPattern: boolean;
    isWildMatchPattern: boolean;
    haveExcludePattern: boolean;
    haveRelativePattern: boolean;
    base: Path;
    relative: string | number;
    data: {
        segments: Segments;
        tree?: Node;
    };
    constructor(input: string, base?: Path);
    parse(): Node;
    append(parent: Node, node: Node): void;
    parseAtom(type: Token): Node;
    pushSegments(key: string | number): void;
    parseIdentifier(): IdentifierNode;
    parseExpandOperator(): ExpandOperatorNode;
    parseWildcardOperator(): WildcardOperatorNode;
    parseDestructorExpression(): DestructorExpressionNode;
    parseArrayPattern(): ArrayPatternNode;
    parseArrayPatternElements(): any[];
    parseObjectPattern(): ObjectPatternNode;
    parseObjectProperties(): ObjectPatternPropertyNode[];
    parseDotOperator(): Node;
    parseIgnoreExpression(): IgnoreExpressionNode;
    parseGroupExpression(parent: Node): GroupExpressionNode;
    parseRangeExpression(parent: Node): RangeExpressionNode;
}
