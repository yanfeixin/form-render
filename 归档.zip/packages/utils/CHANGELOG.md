# @king-one/utils

## 1.0.12

### Patch Changes

- fix：修复，完善页码相关函数

## 1.0.11

### Patch Changes

- fix：修改 base64ToFile 方法

## 1.0.10

### Patch Changes

- feat：增加方法 base64 转 file 对象

## 1.0.9

### Patch Changes

- fix：增加页码验证函数

## 1.0.8

### Patch Changes

- feat：优化验证页码范围的方法

## 1.0.7

### Patch Changes

- feat:主文件导出 number 相关方法

## 1.0.6

### Patch Changes

- feat：增加页面范围计算

## 1.0.5

### Patch Changes

- feat:增加数组内的元素随机排序的方法

## 1.0.4

### Patch Changes

- fix：修复 mmtopx 计算错误

## 1.0.3

### Patch Changes

- feat：增加 mmtopx 的方法

## 1.0.2

### Patch Changes

- feat：优化部分代码

## 1.0.1

### Patch Changes

- 修改 getImgSize 函数的类型

## 1.0.1

### Patch Changes

- feat：初始化发布
