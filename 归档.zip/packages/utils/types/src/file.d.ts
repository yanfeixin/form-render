export declare function base64ToFile(base64: string, filename: string): File;
