export declare const getType: (obj: any) => string;
export declare const isFn: (val: any) => val is Function;
export declare const isArr: (arg: any) => arg is any[];
export declare const isPlainObj: (obj: unknown) => obj is object;
export declare const isStr: (obj: unknown) => obj is string;
export declare const isBool: (obj: unknown) => obj is boolean;
export declare const isNum: (obj: unknown) => obj is number;
export declare function isMap(val: any): val is Map<any, any>;
export declare const isSet: (val: any) => val is Set<any>;
export declare function isWeakMap(val: any): val is WeakMap<any, any>;
export declare function isWeakSet(val: any): val is WeakSet<any>;
export declare function isNumberLike(index: any): index is number;
export declare const isObj: (val: unknown) => val is object;
export declare const isRegExp: (obj: unknown) => obj is RegExp;
export declare function isReactElement(obj: any): boolean;
export declare function isHTMLElement(target: any): target is EventTarget;
export type Subscriber<S> = (payload: S) => void;
export interface Subscription<S> {
    notify?: (payload: S) => void | boolean;
    filter?: (payload: S) => any;
}
