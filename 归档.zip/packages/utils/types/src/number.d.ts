export declare function rangeNumber(range: string): number[];
