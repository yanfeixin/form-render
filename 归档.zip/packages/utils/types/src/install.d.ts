import { App, Directive, Plugin } from 'vue';
export type SFCWithInstall<T> = T & Plugin;
export declare function withInstall<T>(main: T): SFCWithInstall<T>;
export declare function withInstallDirectives<T extends Directive>(main: T, name: string): {
    install: (app: App) => void;
    directive: T;
};
