export declare function getImgSize(url: string, zoom?: number): Promise<{
    width: string;
    height: string;
}>;
export declare function mmtopx(size: number, dpi?: number): number;
