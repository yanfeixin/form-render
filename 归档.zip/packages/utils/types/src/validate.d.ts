export declare function validatePageRange(str: string): boolean;
