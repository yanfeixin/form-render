export declare function uid(len?: number): string;
