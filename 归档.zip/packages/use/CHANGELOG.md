# @king-one/use

## 1.0.11

### Patch Changes

- feat：检测滚动条的 hook,增加参数：增量宽度

## 1.0.10

### Patch Changes

- feat：优化根据元素内容和元素大小变化，检测是否有横向、竖向滚动条的 hook

## 1.0.9

### Patch Changes

- fix：修复 useScrollbars 的参数声明

## 1.0.8

### Patch Changes

- feat：修复 useScrollbars 类型引入错误

## 1.0.7

### Patch Changes

- refactor：优化

## 1.0.6

### Patch Changes

- feat：增加检测是否有滚动条的 hook

## 1.0.5

### Patch Changes

- 修改批量下载传参错误

## 1.0.4

### Patch Changes

- feat：修改批量下载的参数

## 1.0.3

### Patch Changes

- feat:增加额外参数 url

## 1.0.2

### Patch Changes

- fix：修复声明文件生成错误

## 1.0.1

### Patch Changes

- feat：发布
