import { CookiesStatic } from './types';
declare const _default: CookiesStatic<string>;
export default _default;
