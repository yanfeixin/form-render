declare const _default: {
    read(value: any): any;
    write(value: any): string;
};
export default _default;
