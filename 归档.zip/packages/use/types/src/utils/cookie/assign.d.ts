export default function (target: any, ...args: any[]): any;
