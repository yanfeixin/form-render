interface InfoInter {
    token: string;
    custom?: {
        [key: string]: any;
    };
    terminal: string;
    terminalInfo: string;
    platform: string;
}
declare class ErrorReporter {
    private info;
    private userAgent;
    constructor(info: InfoInter);
    errorReportEvent(): void;
    rejectionReportEvent(): void;
    handleGlobalError(message: Event | string, source: any, lineno: any, colno: any, error: any): void;
    handleUnhandledRejection(event: PromiseRejectionEvent): void;
    reportError(errorData: any, type: string): Promise<void>;
}
export default ErrorReporter;
