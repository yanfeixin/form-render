export declare function useSSo(): {
    Guard: (mode?: "history" | "hash") => Promise<void>;
    GoUnifiedLogin: () => Promise<any>;
};
export declare function useToken(): {
    getToken: () => string | undefined;
    setToken: (token: string) => void;
    deleteToken: () => void;
};
