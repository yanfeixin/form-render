import { AxiosRequestConfig } from 'axios';
export interface FileData {
    fileId: string;
    [x: string]: any;
}
export interface batchFileType extends FileData {
    fileImg: string;
}
export declare function batchDownload(fileList: FileData[]): Promise<batchFileType[]>;
export declare function paasBatchDownload<T extends FileData[]>(config: AxiosRequestConfig<T>): Promise<batchFileType[]>;
