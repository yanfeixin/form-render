import { MaybeRef, Ref } from 'vue';
export declare function useScrollDetection(refElement: MaybeRef<HTMLElement | null>, incrementwidth?: number): {
    hasHorizontalScroll: Ref<boolean>;
    hasVerticalScroll: Ref<boolean>;
};
