import { AxiosRequestConfig } from 'axios';
export declare const fileUrl: {
    batchDownloadUrl: string;
};
export declare const fileApi: {
    batchDownload: (config: AxiosRequestConfig) => any;
};
