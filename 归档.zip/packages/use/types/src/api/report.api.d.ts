import { AxiosRequestConfig } from 'axios';
export declare const reportApi: {
    errorReport: (config: AxiosRequestConfig) => any;
};
