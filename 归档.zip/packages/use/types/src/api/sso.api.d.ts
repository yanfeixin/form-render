import { AxiosRequestConfig } from 'axios';
export declare const ssoApi: {
    checkCenterTicket: (config: AxiosRequestConfig) => Promise<any>;
};
