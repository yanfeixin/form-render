export enum ApiPrefixEnum {
  SECURITY = '/security',
  ELECTRONIC = '/electronic',
  BASIC = '/basic',
  FILE = '/file',
  PAAS = '/paas'
}
