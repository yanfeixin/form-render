import { App } from 'vue';
export declare function install(app: App): any;
declare const plugin: {
    install: typeof install;
};
export default plugin;
