import { default as installer } from './installer';
export * from './components';
export default installer;
