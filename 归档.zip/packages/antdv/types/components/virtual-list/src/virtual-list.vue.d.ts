import { VirtualListScrollToOptions, VVirtualListColumn, VVirtualListRenderCol, VVirtualListRenderItemWithCols, VVirtualListItemData, VVirtualListScrollTo } from 'vueuc';
import { CreateComponentPublicInstance, ExtractPropTypes, PropType, Ref, ComputedRef, ComponentOptionsMixin, VNodeProps, AllowedComponentProps, ComponentCustomProps, CSSProperties, DefineComponent, PublicProps } from 'vue';
import { InterScrollParams } from './types';
declare function getScrollContainer(): HTMLElement | null | undefined;
declare function getScrollContent(): HTMLElement | null | undefined;
declare function scrollTo(options: VirtualListScrollToOptions | number, y?: number): void;
declare function __VLS_template(): {
    slots: {
        default?(_: {
            item: any;
            index: any;
        }): any;
    };
    refs: {
        scrollbarInstRef: CreateComponentPublicInstance<Readonly< ExtractPropTypes<{
            readonly container: PropType<() => HTMLElement | null | undefined>;
            readonly content: PropType<() => HTMLElement | null | undefined>;
            readonly onScroll: PropType<(e: Event) => void>;
            readonly xScrollable: BooleanConstructor;
        }>>, {
            sync: () => void;
            handleContentResize: () => void;
            handleContainerResize: () => void;
            contentRef: Ref<HTMLElement | null>;
            yRailRef: Ref<HTMLElement | null>;
            xRailRef: Ref<HTMLElement | null>;
            containerRef: Ref<HTMLElement | null>;
            contentHeightRef: Ref<Nullable<number>>;
            containerHeightRef: Ref<Nullable<number>>;
            needYBarRef: ComputedRef<boolean>;
            needXBarRef: ComputedRef<boolean>;
            yBarSizePxRef: ComputedRef<string>;
            handleYScrollMouseDown: (e: MouseEvent) => void;
            handleXScrollMouseDown: (e: MouseEvent) => void;
            yBarTopPxRef: ComputedRef<string>;
            handleScroll: (e: Event) => void;
            xBarSizePxRef: ComputedRef<string>;
            xBarLeftPxRef: ComputedRef<string>;
        }, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, VNodeProps & AllowedComponentProps & ComponentCustomProps & Readonly< ExtractPropTypes<{
            readonly container: PropType<() => HTMLElement | null | undefined>;
            readonly content: PropType<() => HTMLElement | null | undefined>;
            readonly onScroll: PropType<(e: Event) => void>;
            readonly xScrollable: BooleanConstructor;
        }>>, {
            readonly xScrollable: boolean;
        }, true, {}, {}, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly< ExtractPropTypes<{
            readonly container: PropType<() => HTMLElement | null | undefined>;
            readonly content: PropType<() => HTMLElement | null | undefined>;
            readonly onScroll: PropType<(e: Event) => void>;
            readonly xScrollable: BooleanConstructor;
        }>>, {
            sync: () => void;
            handleContentResize: () => void;
            handleContainerResize: () => void;
            contentRef: Ref<HTMLElement | null>;
            yRailRef: Ref<HTMLElement | null>;
            xRailRef: Ref<HTMLElement | null>;
            containerRef: Ref<HTMLElement | null>;
            contentHeightRef: Ref<Nullable<number>>;
            containerHeightRef: Ref<Nullable<number>>;
            needYBarRef: ComputedRef<boolean>;
            needXBarRef: ComputedRef<boolean>;
            yBarSizePxRef: ComputedRef<string>;
            handleYScrollMouseDown: (e: MouseEvent) => void;
            handleXScrollMouseDown: (e: MouseEvent) => void;
            yBarTopPxRef: ComputedRef<string>;
            handleScroll: (e: Event) => void;
            xBarSizePxRef: ComputedRef<string>;
            xBarLeftPxRef: ComputedRef<string>;
        }, {}, {}, {}, {
            readonly xScrollable: boolean;
        }> | null;
        virtualListInstRef: CreateComponentPublicInstance<Readonly< ExtractPropTypes<{
            showScrollbar: {
                type: BooleanConstructor;
                default: boolean;
            };
            columns: {
                type: PropType< VVirtualListColumn[]>;
                default: () => never[];
            };
            renderCol: PropType<VVirtualListRenderCol>;
            renderItemWithCols: PropType<VVirtualListRenderItemWithCols>;
            items: {
                type: PropType< VVirtualListItemData[]>;
                default: () => never[];
            };
            itemSize: {
                type: NumberConstructor;
                required: true;
            };
            itemResizable: BooleanConstructor;
            itemsStyle: PropType<string | CSSProperties>;
            visibleItemsTag: {
                type: PropType<string | object>;
                default: string;
            };
            visibleItemsProps: ObjectConstructor;
            ignoreItemResize: BooleanConstructor;
            onScroll: PropType<(event: Event) => void>;
            onWheel: PropType<(event: WheelEvent) => void>;
            onResize: PropType<(entry: ResizeObserverEntry) => void>;
            defaultScrollKey: (StringConstructor | NumberConstructor)[];
            defaultScrollIndex: NumberConstructor;
            keyField: {
                type: StringConstructor;
                default: string;
            };
            paddingTop: {
                type: (StringConstructor | NumberConstructor)[];
                default: number;
            };
            paddingBottom: {
                type: (StringConstructor | NumberConstructor)[];
                default: number;
            };
        }>>, {
            listHeight: Ref<number | undefined>;
            listStyle: {
                overflow: string;
            };
            keyToIndex: ComputedRef<Map<any, any>>;
            itemsStyle: ComputedRef<(string | CSSProperties | {
                boxSizing: string;
                width: string | undefined;
                height: string;
                minHeight: string;
                paddingTop: string;
                paddingBottom: string;
            } | undefined)[]>;
            visibleItemsStyle: ComputedRef<{
                transform: string;
            }>;
            viewportItems: ComputedRef< VVirtualListItemData[]>;
            listElRef: Ref<HTMLElement | null>;
            itemsElRef: Ref<Element | null>;
            scrollTo: VVirtualListScrollTo;
            handleListResize: (entry: ResizeObserverEntry) => void;
            handleListScroll: (e: UIEvent) => void;
            handleListWheel: (e: WheelEvent) => void;
            handleItemResize: (key: string | number, entry: ResizeObserverEntry) => void;
        }, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, VNodeProps & AllowedComponentProps & ComponentCustomProps & Readonly< ExtractPropTypes<{
            showScrollbar: {
                type: BooleanConstructor;
                default: boolean;
            };
            columns: {
                type: PropType< VVirtualListColumn[]>;
                default: () => never[];
            };
            renderCol: PropType<VVirtualListRenderCol>;
            renderItemWithCols: PropType<VVirtualListRenderItemWithCols>;
            items: {
                type: PropType< VVirtualListItemData[]>;
                default: () => never[];
            };
            itemSize: {
                type: NumberConstructor;
                required: true;
            };
            itemResizable: BooleanConstructor;
            itemsStyle: PropType<string | CSSProperties>;
            visibleItemsTag: {
                type: PropType<string | object>;
                default: string;
            };
            visibleItemsProps: ObjectConstructor;
            ignoreItemResize: BooleanConstructor;
            onScroll: PropType<(event: Event) => void>;
            onWheel: PropType<(event: WheelEvent) => void>;
            onResize: PropType<(entry: ResizeObserverEntry) => void>;
            defaultScrollKey: (StringConstructor | NumberConstructor)[];
            defaultScrollIndex: NumberConstructor;
            keyField: {
                type: StringConstructor;
                default: string;
            };
            paddingTop: {
                type: (StringConstructor | NumberConstructor)[];
                default: number;
            };
            paddingBottom: {
                type: (StringConstructor | NumberConstructor)[];
                default: number;
            };
        }>>, {
            columns: VVirtualListColumn[];
            showScrollbar: boolean;
            items: VVirtualListItemData[];
            itemResizable: boolean;
            visibleItemsTag: string | object;
            ignoreItemResize: boolean;
            keyField: string;
            paddingTop: string | number;
            paddingBottom: string | number;
        }, true, {}, {}, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly< ExtractPropTypes<{
            showScrollbar: {
                type: BooleanConstructor;
                default: boolean;
            };
            columns: {
                type: PropType< VVirtualListColumn[]>;
                default: () => never[];
            };
            renderCol: PropType<VVirtualListRenderCol>;
            renderItemWithCols: PropType<VVirtualListRenderItemWithCols>;
            items: {
                type: PropType< VVirtualListItemData[]>;
                default: () => never[];
            };
            itemSize: {
                type: NumberConstructor;
                required: true;
            };
            itemResizable: BooleanConstructor;
            itemsStyle: PropType<string | CSSProperties>;
            visibleItemsTag: {
                type: PropType<string | object>;
                default: string;
            };
            visibleItemsProps: ObjectConstructor;
            ignoreItemResize: BooleanConstructor;
            onScroll: PropType<(event: Event) => void>;
            onWheel: PropType<(event: WheelEvent) => void>;
            onResize: PropType<(entry: ResizeObserverEntry) => void>;
            defaultScrollKey: (StringConstructor | NumberConstructor)[];
            defaultScrollIndex: NumberConstructor;
            keyField: {
                type: StringConstructor;
                default: string;
            };
            paddingTop: {
                type: (StringConstructor | NumberConstructor)[];
                default: number;
            };
            paddingBottom: {
                type: (StringConstructor | NumberConstructor)[];
                default: number;
            };
        }>>, {
            listHeight: Ref<number | undefined>;
            listStyle: {
                overflow: string;
            };
            keyToIndex: ComputedRef<Map<any, any>>;
            itemsStyle: ComputedRef<(string | CSSProperties | {
                boxSizing: string;
                width: string | undefined;
                height: string;
                minHeight: string;
                paddingTop: string;
                paddingBottom: string;
            } | undefined)[]>;
            visibleItemsStyle: ComputedRef<{
                transform: string;
            }>;
            viewportItems: ComputedRef< VVirtualListItemData[]>;
            listElRef: Ref<HTMLElement | null>;
            itemsElRef: Ref<Element | null>;
            scrollTo: VVirtualListScrollTo;
            handleListResize: (entry: ResizeObserverEntry) => void;
            handleListScroll: (e: UIEvent) => void;
            handleListWheel: (e: WheelEvent) => void;
            handleItemResize: (key: string | number, entry: ResizeObserverEntry) => void;
        }, {}, {}, {}, {
            columns: VVirtualListColumn[];
            showScrollbar: boolean;
            items: VVirtualListItemData[];
            itemResizable: boolean;
            visibleItemsTag: string | object;
            ignoreItemResize: boolean;
            keyField: string;
            paddingTop: string | number;
            paddingBottom: string | number;
        }> | null;
    };
    attrs: Partial<{}>;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: DefineComponent<{
    readonly items: {
        readonly type: PropType< VVirtualListItemData[]>;
        readonly default: () => never[];
    };
    readonly itemSize: {
        readonly type: NumberConstructor;
        readonly required: true;
    };
    readonly itemResizable: BooleanConstructor;
    readonly paddingTop: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly paddingBottom: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly keyField: {
        readonly type: StringConstructor;
        readonly default: "key";
    };
    readonly xScrollable: BooleanConstructor;
    readonly onScroll: PropType<(params: InterScrollParams) => void>;
    readonly onWheel: PropType<(event: WheelEvent) => void>;
    readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
}, {
    getScrollContainer: typeof getScrollContainer;
    getScrollContent: typeof getScrollContent;
    scrollTo: typeof scrollTo;
}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly< ExtractPropTypes<{
    readonly items: {
        readonly type: PropType< VVirtualListItemData[]>;
        readonly default: () => never[];
    };
    readonly itemSize: {
        readonly type: NumberConstructor;
        readonly required: true;
    };
    readonly itemResizable: BooleanConstructor;
    readonly paddingTop: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly paddingBottom: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly keyField: {
        readonly type: StringConstructor;
        readonly default: "key";
    };
    readonly xScrollable: BooleanConstructor;
    readonly onScroll: PropType<(params: InterScrollParams) => void>;
    readonly onWheel: PropType<(event: WheelEvent) => void>;
    readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
}>>, {
    readonly xScrollable: boolean;
    readonly items: VVirtualListItemData[];
    readonly itemResizable: boolean;
    readonly paddingTop: string | number;
    readonly paddingBottom: string | number;
    readonly keyField: string;
}, {}>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
