import { VirtualListInst, VirtualListItemData } from 'vueuc';
import { PropType } from 'vue';
export interface InterScrollParams {
    viewportItems: any[];
    scrollTop: number;
}
export declare const virtualListProps: {
    readonly items: {
        readonly type: PropType<VirtualListItemData[]>;
        readonly default: () => never[];
    };
    readonly itemSize: {
        readonly type: NumberConstructor;
        readonly required: true;
    };
    readonly itemResizable: BooleanConstructor;
    readonly paddingTop: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly paddingBottom: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly keyField: {
        readonly type: StringConstructor;
        readonly default: "key";
    };
    readonly xScrollable: BooleanConstructor;
    readonly onScroll: PropType<(params: InterScrollParams) => void>;
    readonly onWheel: PropType<(event: WheelEvent) => void>;
    readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
};
export interface VirtualListRef extends VirtualListInst {
    viewportItems: any[];
    visibleItemsStyle: {
        transform: string;
    };
}
