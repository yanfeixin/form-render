import { SFCWithInstall } from '../utils/install';
import { CreateComponentPublicInstance, ExtractPropTypes, PropType, ComponentOptionsMixin, VNodeProps, AllowedComponentProps, ComponentCustomProps, ComponentOptionsBase } from 'vue';
import { VVirtualListItemData, VVirtualListScrollToOptions } from 'vueuc';
import { InterScrollParams } from './src/types';
export * from './src/types';
export declare const KVirtualList: SFCWithInstall<{
    new (...args: any[]): CreateComponentPublicInstance<Readonly< ExtractPropTypes<{
        readonly items: {
            readonly type: PropType< VVirtualListItemData[]>;
            readonly default: () => never[];
        };
        readonly itemSize: {
            readonly type: NumberConstructor;
            readonly required: true;
        };
        readonly itemResizable: BooleanConstructor;
        readonly paddingTop: {
            readonly type: PropType<number | string>;
            readonly default: 0;
        };
        readonly paddingBottom: {
            readonly type: PropType<number | string>;
            readonly default: 0;
        };
        readonly keyField: {
            readonly type: StringConstructor;
            readonly default: "key";
        };
        readonly xScrollable: BooleanConstructor;
        readonly onScroll: PropType<(params: InterScrollParams) => void>;
        readonly onWheel: PropType<(event: WheelEvent) => void>;
        readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
    }>>, {
        getScrollContainer: () => HTMLElement | null | undefined;
        getScrollContent: () => HTMLElement | null | undefined;
        scrollTo: (options: VVirtualListScrollToOptions | number, y?: number) => void;
    }, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, VNodeProps & AllowedComponentProps & ComponentCustomProps & Readonly< ExtractPropTypes<{
        readonly items: {
            readonly type: PropType< VVirtualListItemData[]>;
            readonly default: () => never[];
        };
        readonly itemSize: {
            readonly type: NumberConstructor;
            readonly required: true;
        };
        readonly itemResizable: BooleanConstructor;
        readonly paddingTop: {
            readonly type: PropType<number | string>;
            readonly default: 0;
        };
        readonly paddingBottom: {
            readonly type: PropType<number | string>;
            readonly default: 0;
        };
        readonly keyField: {
            readonly type: StringConstructor;
            readonly default: "key";
        };
        readonly xScrollable: BooleanConstructor;
        readonly onScroll: PropType<(params: InterScrollParams) => void>;
        readonly onWheel: PropType<(event: WheelEvent) => void>;
        readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
    }>>, {
        readonly xScrollable: boolean;
        readonly items: VVirtualListItemData[];
        readonly itemResizable: boolean;
        readonly paddingTop: string | number;
        readonly paddingBottom: string | number;
        readonly keyField: string;
    }, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly< ExtractPropTypes<{
        readonly items: {
            readonly type: PropType< VVirtualListItemData[]>;
            readonly default: () => never[];
        };
        readonly itemSize: {
            readonly type: NumberConstructor;
            readonly required: true;
        };
        readonly itemResizable: BooleanConstructor;
        readonly paddingTop: {
            readonly type: PropType<number | string>;
            readonly default: 0;
        };
        readonly paddingBottom: {
            readonly type: PropType<number | string>;
            readonly default: 0;
        };
        readonly keyField: {
            readonly type: StringConstructor;
            readonly default: "key";
        };
        readonly xScrollable: BooleanConstructor;
        readonly onScroll: PropType<(params: InterScrollParams) => void>;
        readonly onWheel: PropType<(event: WheelEvent) => void>;
        readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
    }>>, {
        getScrollContainer: () => HTMLElement | null | undefined;
        getScrollContent: () => HTMLElement | null | undefined;
        scrollTo: (options: VVirtualListScrollToOptions | number, y?: number) => void;
    }, {}, {}, {}, {
        readonly xScrollable: boolean;
        readonly items: VVirtualListItemData[];
        readonly itemResizable: boolean;
        readonly paddingTop: string | number;
        readonly paddingBottom: string | number;
        readonly keyField: string;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & ComponentOptionsBase<Readonly< ExtractPropTypes<{
    readonly items: {
        readonly type: PropType< VVirtualListItemData[]>;
        readonly default: () => never[];
    };
    readonly itemSize: {
        readonly type: NumberConstructor;
        readonly required: true;
    };
    readonly itemResizable: BooleanConstructor;
    readonly paddingTop: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly paddingBottom: {
        readonly type: PropType<number | string>;
        readonly default: 0;
    };
    readonly keyField: {
        readonly type: StringConstructor;
        readonly default: "key";
    };
    readonly xScrollable: BooleanConstructor;
    readonly onScroll: PropType<(params: InterScrollParams) => void>;
    readonly onWheel: PropType<(event: WheelEvent) => void>;
    readonly onResize: PropType<(entry: ResizeObserverEntry) => void>;
}>>, {
    getScrollContainer: () => HTMLElement | null | undefined;
    getScrollContent: () => HTMLElement | null | undefined;
    scrollTo: (options: VVirtualListScrollToOptions | number, y?: number) => void;
}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, {
    readonly xScrollable: boolean;
    readonly items: VVirtualListItemData[];
    readonly itemResizable: boolean;
    readonly paddingTop: string | number;
    readonly paddingBottom: string | number;
    readonly keyField: string;
}, {}, string, {}> & VNodeProps & AllowedComponentProps & ComponentCustomProps & (new () => {
    $slots: {
        default?(_: {
            item: any;
            index: any;
        }): any;
    };
})>;
export default KVirtualList;
