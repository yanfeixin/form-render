import { ExtractPropTypes, PropType } from 'vue';
export declare const collapseProps: {
    readonly mode: {
        readonly type: PropType<"horizontal" | "vertical">;
        readonly required: true;
    };
};
export type ExtractProps = ExtractPropTypes<typeof collapseProps>;
