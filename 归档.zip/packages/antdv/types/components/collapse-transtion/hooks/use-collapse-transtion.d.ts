import { RendererElement } from 'vue';
import { ExtractProps } from '../src/types';
export declare function useCollapseTranstion(props: ExtractProps): {
    beforeEnter(el: RendererElement): void;
    enter(el: RendererElement): void;
    afterEnter(el: RendererElement): void;
    enterCancelled(el: RendererElement): void;
    beforeLeave(el: RendererElement): void;
    leave(el: RendererElement): void;
    afterLeave(el: RendererElement): void;
    leaveCancelled(el: RendererElement): void;
};
