import { DefineComponent, PropType, Ref, ComputedRef, ComponentOptionsMixin, PublicProps, ExtractPropTypes } from 'vue';
declare const _default: DefineComponent<{
    readonly container: PropType<() => HTMLElement | null | undefined>;
    readonly content: PropType<() => HTMLElement | null | undefined>;
    readonly onScroll: PropType<(e: Event) => void>;
    readonly xScrollable: BooleanConstructor;
}, {
    sync: () => void;
    handleContentResize: () => void;
    handleContainerResize: () => void;
    contentRef: Ref<HTMLElement | null>;
    yRailRef: Ref<HTMLElement | null>;
    xRailRef: Ref<HTMLElement | null>;
    containerRef: Ref<HTMLElement | null>;
    contentHeightRef: Ref<Nullable<number>>;
    containerHeightRef: Ref<Nullable<number>>;
    needYBarRef: ComputedRef<boolean>;
    needXBarRef: ComputedRef<boolean>;
    yBarSizePxRef: ComputedRef<string>;
    handleYScrollMouseDown: (e: MouseEvent) => void;
    handleXScrollMouseDown: (e: MouseEvent) => void;
    yBarTopPxRef: ComputedRef<string>;
    handleScroll: (e: Event) => void;
    xBarSizePxRef: ComputedRef<string>;
    xBarLeftPxRef: ComputedRef<string>;
}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly< ExtractPropTypes<{
    readonly container: PropType<() => HTMLElement | null | undefined>;
    readonly content: PropType<() => HTMLElement | null | undefined>;
    readonly onScroll: PropType<(e: Event) => void>;
    readonly xScrollable: BooleanConstructor;
}>>, {
    readonly xScrollable: boolean;
}, {}>;
export default _default;
