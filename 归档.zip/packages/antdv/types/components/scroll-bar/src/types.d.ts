import { PropType } from 'vue';
export declare const scrollbarProps: {
    readonly container: PropType<() => HTMLElement | null | undefined>;
    readonly content: PropType<() => HTMLElement | null | undefined>;
    readonly onScroll: PropType<(e: Event) => void>;
    readonly xScrollable: BooleanConstructor;
};
