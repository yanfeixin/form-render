import { Ref } from 'vue';
export interface DialogMethods {
    openDialog: () => void;
    closeDialog: () => void;
}
export declare function useProDialog(): {
    dialogVisible: Ref<boolean>;
    openDialog: () => void;
    closeDialog: () => void;
};
export declare function useProDialogInit(): [
    (methods: DialogMethods) => void,
    DialogMethods
];
