import { SFCWithInstall } from '../utils/install';
import { DefineComponent, PropType, ComponentOptionsMixin, PublicProps, ExtractPropTypes } from 'vue';
import { ModalProps } from 'ant-design-vue';
export * from './hooks/useProDialog';
export * from './src/types';
export declare const KProDialog: SFCWithInstall<DefineComponent<{
    dialogProps: {
        readonly type: PropType<Omit< ModalProps, "open">>;
    };
    modelValue: {
        type: PropType<boolean>;
        required: true;
    };
}, {}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    "update:modelValue": (modelValue: boolean) => void;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    dialogProps: {
        readonly type: PropType<Omit< ModalProps, "open">>;
    };
    modelValue: {
        type: PropType<boolean>;
        required: true;
    };
}>> & {
    "onUpdate:modelValue"?: ((modelValue: boolean) => any) | undefined;
}, {}, {}>>;
