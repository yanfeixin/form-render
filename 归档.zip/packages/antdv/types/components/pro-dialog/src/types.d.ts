import { ModalProps } from 'ant-design-vue';
import { PropType } from 'vue';
export declare const proDialogProps: {
    readonly dialogProps: {
        readonly type: PropType<Omit<ModalProps, "open">>;
    };
};
