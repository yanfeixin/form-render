import { DefineComponent, PropType, ComponentOptionsMixin, PublicProps, ExtractPropTypes } from 'vue';
import { ModalProps } from 'ant-design-vue';
declare const _default: DefineComponent<{
    dialogProps: {
        readonly type: PropType<Omit< ModalProps, "open">>;
    };
    modelValue: {
        type: PropType<boolean>;
        required: true;
    };
}, {}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    "update:modelValue": (modelValue: boolean) => void;
}, string, PublicProps, Readonly< ExtractPropTypes<{
    dialogProps: {
        readonly type: PropType<Omit< ModalProps, "open">>;
    };
    modelValue: {
        type: PropType<boolean>;
        required: true;
    };
}>> & {
    "onUpdate:modelValue"?: ((modelValue: boolean) => any) | undefined;
}, {}, {}>;
export default _default;
