import { SFCWithInstall } from '../utils/install';
import { CreateComponentPublicInstance, ExtractPropTypes, PropType, ComponentOptionsMixin, VNodeProps, AllowedComponentProps, ComponentCustomProps, ComponentOptionsBase } from 'vue';
import { RuleItem } from 'async-validator';
export * from './component/form';
export declare const KForm: SFCWithInstall<{
    new (...args: any[]): CreateComponentPublicInstance<Readonly< ExtractPropTypes<{
        readonly model: {
            readonly type: ObjectConstructor;
        };
        readonly rules: {
            readonly type: PropType<Record<string, RuleItem[]>>;
        };
    }>>, {}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, VNodeProps & AllowedComponentProps & ComponentCustomProps & Readonly< ExtractPropTypes<{
        readonly model: {
            readonly type: ObjectConstructor;
        };
        readonly rules: {
            readonly type: PropType<Record<string, RuleItem[]>>;
        };
    }>>, {}, true, {}, {}, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly< ExtractPropTypes<{
        readonly model: {
            readonly type: ObjectConstructor;
        };
        readonly rules: {
            readonly type: PropType<Record<string, RuleItem[]>>;
        };
    }>>, {}, {}, {}, {}, {}>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & ComponentOptionsBase<Readonly< ExtractPropTypes<{
    readonly model: {
        readonly type: ObjectConstructor;
    };
    readonly rules: {
        readonly type: PropType<Record<string, RuleItem[]>>;
    };
}>>, {}, unknown, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, {}, {}, string, {}> & VNodeProps & AllowedComponentProps & ComponentCustomProps & (new () => {
    $slots: {
        default?(_: {}): any;
    };
})>;
export default KForm;
