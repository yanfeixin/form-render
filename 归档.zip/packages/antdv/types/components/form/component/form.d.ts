import { RuleItem } from 'async-validator';
import { PropType } from 'vue';
export declare const formType: {
    readonly model: {
        readonly type: ObjectConstructor;
    };
    readonly rules: {
        readonly type: PropType<Record<string, RuleItem[]>>;
    };
};
