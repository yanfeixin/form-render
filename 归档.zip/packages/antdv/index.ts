import installer from './installer'

export * from './components'
export default installer
