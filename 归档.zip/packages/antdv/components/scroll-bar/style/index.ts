import '@king-one/antdv/components/base/style'
import '@king-one/theme-chalk/src/scroll-bar.scss'
