# @king-one/antdv

## 1.0.22

### Patch Changes

- feat：增加 dialog 组件

## 1.0.21

### Patch Changes

- build：优化项目构建的文件

## 1.0.20

### Patch Changes

- feat：虚拟列表组件增加相关方法

## 1.0.19

### Patch Changes

- fix: 修复初始化时的滚动条计算

## 1.0.18

### Patch Changes

- fix: 修复 class 绑定错误

## 1.0.17

### Patch Changes

- feat：虚拟列表增加 xscroll 加 x

## 1.0.16

### Patch Changes

- fix：修复 collapse-transtion 组件无效

## 1.0.15

### Patch Changes

- fix：修复 collapse-transtion 组件的导出

## 1.0.14

### Patch Changes

- feat：新开发转换过度 CollapseTranstion 组件

## 1.0.13

### Patch Changes

- fix：修改虚拟列表滚动事件的参数问题

## 1.0.12

### Patch Changes

- test：测试

## 1.0.11

### Patch Changes

- fix：修复 scorll 参数

## 1.0.10

### Patch Changes

- fix：修复 scroll 事件的参数

## 1.0.9

### Patch Changes

- feat：增加 VirtualList 滚动事件

## 1.0.8

### Patch Changes

- fix：修改 css 文件引用

## 1.0.7

### Patch Changes

- feat: 修改@king-one/utils 的引用

## 1.0.6

### Patch Changes

- test：测试提交发布

## 1.0.0

### Major Changes

- feat：虚拟列表、滚动条
