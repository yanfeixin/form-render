declare module '@manypkg/get-packages' {
  export function getPackages(cwd: string): Promise<any>
}
