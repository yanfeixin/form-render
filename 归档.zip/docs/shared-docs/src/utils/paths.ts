import { resolve } from 'node:path'

export const projRoot = resolve(__dirname, '..', '..')

// Dvitepressocs
export const vpRoot = resolve(projRoot, '.vitepress')
