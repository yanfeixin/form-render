<script setup>
</script>

<template>
  <IButton class="button" type="primary">
    按钮实例
  </IButton>
  <IButton class="button" type="success">
    按钮实例
  </IButton>
  <IButton class="button" type="error">
    按钮实例
  </IButton>
</template>

<style scoped>
  .button {
    margin-right: 20px;
  }
</style>
